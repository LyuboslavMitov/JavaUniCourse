package bg.sofia.uni.fmi.jira;

import java.time.LocalDateTime;

import bg.sofia.uni.fmi.jira.enums.IssuePriority;
import bg.sofia.uni.fmi.jira.enums.IssueResolution;
import bg.sofia.uni.fmi.jira.enums.IssueStatus;
import bg.sofia.uni.fmi.jira.enums.IssueType;
import bg.sofia.uni.fmi.jira.interfaces.IIssue;
import bg.sofia.uni.fmi.jira.issues.exceptions.InvalidReporterException;

public abstract class Issue implements IIssue {
	private IssuePriority priority;
	private Component component;
	private User reporter;
	private String description;
	private IssueResolution resolution;
	private IssueStatus status;
	private IssueType type;
	private LocalDateTime created;
	private LocalDateTime updated;
	private static int Id=1;
	
	public Issue(IssuePriority priority, Component component, User reporter, String description,IssueType type) throws InvalidReporterException {
		this.priority=priority;
		this.component=component;
		//validate
		this.reporter=reporter;
		this.description=description;
		this.type=type;
		resolution=IssueResolution.UNRESOLVED;
		status = IssueStatus.OPEN;
		created = LocalDateTime.now();
		updated= LocalDateTime.now();
		
	}
	
	public IssueStatus getStatus() {
		return status;
	}
	
	public IssuePriority getPriority() {
		return priority;
	}
	public IssueResolution getResolution() {
		return resolution;
	}
	public LocalDateTime getCreated() {
		return created;
	}
	public String getComponentName() {
		return component.getName();
	}
	@Override
	public String getId() {
		
		return component.getName() + "-" + Id++;
	}

	@Override
	public void resolve(IssueResolution resolution) {
		this.resolution=resolution;
		updated=LocalDateTime.now();
	}

	@Override
	public void setStatus(IssueStatus status) {
		this.status=status;
		updated=LocalDateTime.now();
	}
	public IssueType getType() {
		return type;
	}
	
}
