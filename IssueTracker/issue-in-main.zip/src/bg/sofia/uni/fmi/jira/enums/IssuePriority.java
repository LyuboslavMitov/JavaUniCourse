package bg.sofia.uni.fmi.jira.enums;

public enum IssuePriority {
	TRIVIAL, MINOR, MAJOR, CRITICAL;
}
