package bg.sofia.uni.fmi.jira;

import java.time.LocalDateTime;

import bg.sofia.uni.fmi.jira.enums.IssuePriority;
import bg.sofia.uni.fmi.jira.enums.IssueResolution;
import bg.sofia.uni.fmi.jira.enums.IssueStatus;
import bg.sofia.uni.fmi.jira.enums.IssueType;
import bg.sofia.uni.fmi.jira.interfaces.IssueTracker;

public class Jira implements IssueTracker {
	private Issue[] issues;
	
	public Jira(Issue[] issues) {
		this.issues=issues;
	}
	
	@Override
	public Issue[] findAll(Component component, IssueStatus status) {
		Issue[] result = new Issue[issues.length];
		int counter = 0;
		for(int i=0;i<issues.length;i++) {
			if(issues[i].getComponentName().equals(component.getName()) && issues[i].getStatus()==status) {
				result[counter++]=issues[i];
			}
		}
		return result;
	}

	@Override
	public Issue[] findAll(Component component, IssuePriority priority) {
		Issue[] result = new Issue[issues.length];
		int counter = 0;
		for(int i=0;i<issues.length;i++) {
			if(issues[i].getComponentName().equals(component.getName()) && issues[i].getPriority()==priority) {
				result[counter++]=issues[i];
			}
		}
		return result;
	}

	@Override
	public Issue[] findAll(Component component, IssueType type) {
		Issue[] result = new Issue[issues.length];
		int counter = 0;
		for(int i=0;i<issues.length;i++) {
			if(issues[i].getComponentName().equals(component.getName()) && issues[i].getType()==type) {
				result[counter++]=issues[i];
			}
		}
		return result;
	}

	@Override
	public Issue[] findAll(Component component, IssueResolution resolution) {
		Issue[] result = new Issue[issues.length];
		int counter = 0;
		for(int i=0;i<issues.length;i++) {
			if(issues[i].getComponentName().equals(component.getName()) && issues[i].getResolution()==resolution) {
				result[counter++]=issues[i];
			}
		}
		return result;
	}

	@Override
	public Issue[] findAllIssuesCreatedBetween(LocalDateTime startTime, LocalDateTime endTime) {
		Issue[] result = new Issue[issues.length];
		int counter = 0;
		for(int i=0;i<issues.length;i++) {
			if(issues[i].getCreated().isAfter(startTime) && issues[i].getCreated().isBefore(endTime)) {
				result[counter++]=issues[i];
			}
		}
		return result;
	}

	@Override
	public Issue[] findAllBefore(LocalDateTime dueTime) {
		Issue[] result = new Issue[issues.length];
		int counter = 0;
		for(int i=0;i<issues.length;i++) {
			if(issues[i].getCreated().isBefore(dueTime)) {
				result[counter++]=issues[i];
			}
		}
		return result;
	}

}
