package bg.sofia.uni.fmi.jira.issues;

import java.time.LocalDateTime;

import bg.sofia.uni.fmi.jira.Component;
import bg.sofia.uni.fmi.jira.User;
import bg.sofia.uni.fmi.jira.enums.IssuePriority;
import bg.sofia.uni.fmi.jira.enums.IssueType;
import bg.sofia.uni.fmi.jira.issues.exceptions.InvalidReporterException;

public class NewFeature extends AbstractTask{

	public NewFeature(IssuePriority priority, Component component, User reporter, String description,IssueType type)
			throws InvalidReporterException {
		super(priority, component, reporter, description,type);
		
	}
	public NewFeature(IssuePriority priority, Component component, User reporter, String description,
			LocalDateTime dueTime) throws InvalidReporterException {
		super(priority, component, reporter, description,IssueType.NEW_FEATURE, dueTime);
		// TODO Auto-generated constructor stub
	}

}
