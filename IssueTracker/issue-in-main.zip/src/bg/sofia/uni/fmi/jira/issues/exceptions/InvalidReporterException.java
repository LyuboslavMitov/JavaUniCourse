package bg.sofia.uni.fmi.jira.issues.exceptions;

public class InvalidReporterException extends Exception {

}
