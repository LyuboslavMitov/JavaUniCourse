package bg.sofia.uni.fmi.jira.issues;

import java.time.LocalDateTime;

import bg.sofia.uni.fmi.jira.Component;
import bg.sofia.uni.fmi.jira.Issue;
import bg.sofia.uni.fmi.jira.User;
import bg.sofia.uni.fmi.jira.enums.IssuePriority;
import bg.sofia.uni.fmi.jira.enums.IssueType;
import bg.sofia.uni.fmi.jira.issues.exceptions.InvalidReporterException;

public abstract class AbstractTask extends Issue{
	
	private LocalDateTime dueTime;
	
	public AbstractTask(IssuePriority priority, Component component, User reporter, String description,IssueType type)
			throws InvalidReporterException {
		super(priority, component, reporter, description,type);
		
	}
	public AbstractTask(IssuePriority priority, Component component, User reporter, String description,IssueType type,LocalDateTime dueTime) throws InvalidReporterException {
		this(priority,component,reporter,description,type);
		this.dueTime=dueTime;
	}
}
